"""An OpenAI-compatible chat endpoint (`POST {base_url}/chat/completions`,
streamed) as a thread engine: a local Ollama, LM Studio or vLLM server, or a
hosted API that speaks the same protocol.

Chat only. No tools, so no approvals and no computer; the engine keeps no
session, so each turn sends the conversation's stored history (user and
assistant messages, newest kept within a size limit) with the agent's
instructions as the system message.

The endpoint's address and key are saved through the encrypted engine
configuration (app/services/engine_config.py). The key goes only into the
`Authorization` header of requests to that address: it is never logged,
returned by the API, written to an event or put in the decision log, and an
error message from the endpoint has it removed before it is shown.

`OpenRouterAdapter` at the end is a preset of the same engine: OpenRouter's
address filled in, its key required, and OpenRouter's optional app-attribution
headers (sent to openrouter.ai only).
"""

import asyncio
import json
from urllib.parse import urlsplit

import httpx

from app.core import app_settings
from app.core.logging import get_logger
from app.services.provider_adapter import (
    Capabilities,
    EngineProbe,
    ModelOption,
    ProviderStatus,
    ReplayAborted,
    TurnContext,
    TurnOutcome,
)

logger = get_logger(__name__)

PROBE_TIMEOUT_SECONDS = 5.0
CONNECT_TIMEOUT_SECONDS = 15.0
HISTORY_CHARS = 120_000
MAX_ERROR_CHARS = 500
MAX_MODELS = 200

NOT_CONFIGURED = "Set the endpoint's address (and key, if it needs one) in Settings → Engines."

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_HOST = "openrouter.ai"
# OpenRouter's optional app attribution (its public app rankings).
OPENROUTER_ATTRIBUTION = {"HTTP-Referer": "https://github.com/Anil-matcha/open-duet", "X-Title": "Open Duet"}


class InvalidConfig(ValueError):
    pass


def check_base_url(value) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InvalidConfig("Give the endpoint's address, for example http://127.0.0.1:11434/v1.")
    url = value.strip().rstrip("/")
    if len(url) > 500 or any(ord(c) < 33 for c in url):
        raise InvalidConfig("The address must be one URL without spaces.")
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise InvalidConfig("The address must start with http:// or https://.")
    if parts.username or parts.password or parts.query or parts.fragment:
        raise InvalidConfig("Put the key in the key field, not in the address; no query or fragment.")
    return url


def redact(text: str, secret: str | None) -> str:
    if secret and secret in text:
        text = text.replace(secret, "[redacted]")
    return text


def chat_messages(items: list[dict], instructions: str | None) -> list[dict]:
    """The stored history as chat messages, oldest dropped past the limit."""
    messages = []
    for item in items:
        role, text = item.get("role"), item.get("text")
        if role in ("user", "assistant") and isinstance(text, str) and text.strip():
            messages.append({"role": role, "content": text})
    total = 0
    kept: list[dict] = []
    for message in reversed(messages):
        total += len(message["content"])
        if kept and total > HISTORY_CHARS:
            break
        kept.append(message)
    kept.reverse()
    # A chat starts with the person: an orphaned assistant reply goes.
    while kept and kept[0]["role"] != "user":
        kept.pop(0)
    if instructions:
        kept.insert(0, {"role": "system", "content": instructions})
    return kept


class OpenAIChatAdapter:
    config_fields = [
        {"name": "base_url", "label": "Base URL", "kind": "url", "required": True,
         "placeholder": "https://api.example.com/v1"},
        {"name": "model", "label": "Default model", "placeholder": "Use endpoint default"},
        {"name": "api_key", "label": "API key", "kind": "secret",
         "help": "Encrypted at rest. Leave empty to keep the saved key for this address."},
    ]
    setup = {
        "credential": "api_key",
        "notes": ["Changing the address drops the saved key unless you enter it again. Chat only."],
    }
    key = "openai_compat"
    label = "OpenAI-compatible"
    kind = "api"
    capabilities = Capabilities(
        tools=False, approvals=False, mcp=False, images=False, resume=True, computers=False
    )
    models: list[ModelOption] = []
    custom_models = True
    needs_config = True
    max_models = MAX_MODELS
    # No session: every turn replays the stored conversation, folded when it
    # outgrows the budget (context_compaction.py). `context_tokens` in the
    # saved configuration (the model's context window) sets the budget.
    replays_history = True
    compact_at_tokens = 24_000
    # What status, probe and a turn say while nothing usable is saved.
    not_configured = NOT_CONFIGURED

    def __init__(self, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.config: dict | None = None
        # Tests pass a mock transport; real runs use the network.
        self._transport = transport

    def new_session_id(self) -> None:
        return None

    def _client(self, timeout: httpx.Timeout) -> httpx.AsyncClient:
        return httpx.AsyncClient(timeout=timeout, transport=self._transport, follow_redirects=False)

    # -- configuration --------------------------------------------------------------

    def validate_config(self, payload: dict, current: dict | None) -> dict:
        current = current or {}
        config = {"base_url": check_base_url(payload.get("base_url"))}
        model = payload.get("model")
        if model is not None and not isinstance(model, str):
            raise InvalidConfig("The default model must be text.")
        if model and model.strip():
            from app.services.engine_registry import InvalidModel, check_model_id

            try:
                check_model_id(model.strip())
            except InvalidModel as exc:
                raise InvalidConfig(str(exc)) from None
            config["model"] = model.strip()
        window = payload.get("context_tokens")
        if window is not None:
            if isinstance(window, bool) or not isinstance(window, int) or not 1_024 <= window <= 10_000_000:
                raise InvalidConfig("The context window must be a whole number of tokens from 1024 to 10000000.")
            config["context_tokens"] = window
        key = payload.get("api_key")
        if payload.get("clear_api_key"):
            pass
        elif isinstance(key, str) and key.strip():
            if len(key) > 4096 or any(ord(c) < 33 for c in key.strip()):
                raise InvalidConfig("The key must be one line without spaces.")
            config["api_key"] = key.strip()
        elif current.get("api_key") and current.get("base_url") == config["base_url"]:
            # Kept only for the same address: a key is never sent somewhere new
            # without being given again.
            config["api_key"] = current["api_key"]
        return config

    def public_config(self, config: dict | None) -> dict | None:
        if not config:
            return None
        public = {
            "base_url": config.get("base_url"),
            "model": config.get("model"),
            "has_api_key": bool(config.get("api_key")),
        }
        if config.get("context_tokens"):
            public["context_tokens"] = config["context_tokens"]
        return public

    def _headers(self, config: dict) -> dict:
        headers = {"Accept": "application/json"}
        if config.get("api_key"):
            headers["Authorization"] = f"Bearer {config['api_key']}"
        return headers

    # -- status --------------------------------------------------------------------------

    async def status(self) -> ProviderStatus:
        config = self.config or {}
        if not config.get("base_url"):
            return ProviderStatus(ready=False, error=self.not_configured, installed=False)
        return ProviderStatus(ready=True, installed=True)

    async def probe(self) -> EngineProbe:
        config = self.config or {}
        base = config.get("base_url")
        if not base:
            return EngineProbe(installed=False, ready=False, reason=self.not_configured)
        default = config.get("model")
        try:
            async with self._client(httpx.Timeout(PROBE_TIMEOUT_SECONDS)) as client:
                response = await client.get(f"{base}/models", headers=self._headers(config))
        except httpx.HTTPError as exc:
            return EngineProbe(
                installed=True, ready=False,
                reason=f"The endpoint did not answer ({exc.__class__.__name__}).",
                models=[ModelOption(default, default, True)] if default else None,
            )
        if response.status_code in (401, 403):
            return EngineProbe(installed=True, ready=False, signed_in=False, reason="The endpoint refused the key.")
        models: list[ModelOption] = []
        if response.status_code == 200:
            try:
                data = response.json().get("data")
            except (ValueError, AttributeError):
                data = None
            for item in (data if isinstance(data, list) else [])[:self.max_models]:
                if isinstance(item, dict) and isinstance(item.get("id"), str):
                    mid = item["id"]
                    is_reasoning = any(p in mid.lower() for p in ("o1", "o3-mini", "o3", "o4", "r1"))
                    efforts = ("low", "medium", "high") if is_reasoning else ()
                    models.append(
                        ModelOption(
                            mid,
                            mid,
                            mid == default,
                            default_reasoning_effort="medium" if is_reasoning else None,
                            supported_reasoning_efforts=efforts,
                            reasoning_effort_configurable=bool(efforts),
                        )
                    )
        if default and default not in {m.id for m in models}:
            is_def_reasoning = any(p in default.lower() for p in ("o1", "o3-mini", "o3", "o4", "r1"))
            def_efforts = ("low", "medium", "high") if is_def_reasoning else ()
            models.insert(
                0,
                ModelOption(
                    default,
                    default,
                    True,
                    default_reasoning_effort="medium" if is_def_reasoning else None,
                    supported_reasoning_efforts=def_efforts,
                    reasoning_effort_configurable=bool(def_efforts),
                ),
            )
        return EngineProbe(
            installed=True, ready=True, signed_in=True if config.get("api_key") else None, models=models or None
        )

    # -- a turn ----------------------------------------------------------------------------

    async def generate_text(
        self, prompt: str, *, config: dict | None = None, model: str | None = None, timeout: float = 60,
        on_usage=None,
    ) -> str:
        """One quick answer to `prompt` for background work (memory upkeep):
        a single non-streamed request to the same endpoint and key as the
        agent's own turns. Raises RuntimeError when it fails."""
        config = config or self.config or {}
        base = config.get("base_url")
        model = model or config.get("model")
        if not base or not model:
            raise RuntimeError("This endpoint has no address or model for a background call.")
        body = {"model": model, "messages": [{"role": "user", "content": prompt}], "stream": False}
        try:
            async with self._client(httpx.Timeout(timeout, connect=CONNECT_TIMEOUT_SECONDS)) as client:
                response = await client.post(f"{base}/chat/completions", headers=self._headers(config), json=body)
            if response.status_code != 200:
                raise RuntimeError(f"The endpoint refused the background call ({response.status_code}).")
            answer = response.json()
            usage = answer.get("usage")
            if on_usage is not None and isinstance(usage, dict):
                on_usage({
                    ours: usage[theirs]
                    for theirs, ours in (("prompt_tokens", "input_tokens"), ("completion_tokens", "output_tokens"))
                    if isinstance(usage.get(theirs), int)
                })
            choices = answer.get("choices") or []
            text = ((choices[0] or {}).get("message") or {}).get("content") if choices else None
        except (httpx.HTTPError, ValueError, AttributeError, TypeError) as exc:
            raise RuntimeError(f"The background call failed ({exc.__class__.__name__}).") from None
        if not isinstance(text, str) or not text.strip():
            raise RuntimeError("The endpoint gave no answer for the background call.")
        return text

    async def run_turn(self, ctx: TurnContext, sink, gate) -> TurnOutcome:
        config = ctx.engine_config or self.config or {}
        base = config.get("base_url")
        if not base:
            return TurnOutcome("failed", error=self.not_configured, error_code="engine_not_configured")
        if ctx.computer is not None:
            return TurnOutcome(
                "failed", error="This engine cannot use an agent computer.", error_code="engine_without_computers"
            )
        model = ctx.model or config.get("model")
        if not model:
            return TurnOutcome(
                "failed", error="Choose a model for this endpoint (on the agent, the conversation, or the engine).",
                error_code="no_model",
            )
        secret = config.get("api_key")
        try:
            messages = chat_messages(await ctx.history(), ctx.instructions)
        except ReplayAborted:
            return TurnOutcome(
                "failed", error="The run was stopped because it no longer owns its turn.", error_code="lost", model=model
            )
        if not messages or messages[-1].get("role") != "user":
            messages.append({"role": "user", "content": ctx.prompt})
        else:
            # The stored message is what the person typed; the engine gets the
            # turn's prompt (attached text files, recalled passages).
            messages[-1] = {"role": "user", "content": ctx.prompt}
        loop = asyncio.get_running_loop()
        state = {"text": "", "usage": None, "finish": None, "error": None, "code": None}
        max_text = app_settings.get("LOCAL_MAX_OUTPUT_BYTES")

        async def stream() -> None:
            body = {"model": model, "messages": messages, "stream": True, "stream_options": {"include_usage": True}}
            if ctx.effort:
                body["reasoning_effort"] = ctx.effort.lower()
            task_timeout = app_settings.get("LOCAL_TASK_TIMEOUT_SECONDS")
            timeout = httpx.Timeout(task_timeout or None, connect=CONNECT_TIMEOUT_SECONDS)
            async with self._client(timeout) as client:
                async with client.stream(
                    "POST", f"{base}/chat/completions", headers=self._headers(config), json=body
                ) as response:
                    if response.status_code != 200:
                        raw = (await response.aread())[:4000].decode("utf-8", errors="replace")
                        state["error"] = _error_text(response.status_code, raw, secret)
                        state["code"] = "endpoint_refused" if response.status_code in (401, 403) else "endpoint_error"
                        return
                    async for line in response.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                        except ValueError:
                            continue
                        if isinstance(chunk.get("error"), (dict, str)):
                            err = chunk["error"]
                            message = err.get("message") if isinstance(err, dict) else err
                            state["error"] = redact(str(message), secret)[:MAX_ERROR_CHARS]
                            state["code"] = "endpoint_error"
                            return
                        usage = chunk.get("usage")
                        if isinstance(usage, dict):
                            state["usage"] = {
                                ours: usage[theirs]
                                for theirs, ours in (("prompt_tokens", "input_tokens"), ("completion_tokens", "output_tokens"))
                                if isinstance(usage.get(theirs), int)
                            } or None
                        for choice in chunk.get("choices") or []:
                            if not isinstance(choice, dict):
                                continue
                            delta = choice.get("delta") if isinstance(choice.get("delta"), dict) else {}
                            piece = delta.get("content")
                            if isinstance(piece, str) and piece:
                                state["text"] += piece
                                if len(state["text"].encode("utf-8")) > max_text:
                                    state["error"] = "The endpoint produced more output than allowed"
                                    state["code"] = "output_too_large"
                                    return
                                if not sink.lost:
                                    sink.delta(piece)
                            if choice.get("finish_reason"):
                                state["finish"] = choice["finish_reason"]

        task = asyncio.create_task(stream())
        ctx.on_abort(lambda: loop.call_soon_threadsafe(task.cancel))
        try:
            await task
        except asyncio.CancelledError:
            if not ctx.aborted:
                raise
        except httpx.TimeoutException:
            state["error"], state["code"] = (
                f"Timed out after {app_settings.get('LOCAL_TASK_TIMEOUT_SECONDS')} seconds", "timeout"
            )
        except httpx.HTTPError as exc:
            state["error"] = f"The endpoint could not be reached ({exc.__class__.__name__})."
            state["code"] = "endpoint_unreachable"

        partial = state["text"] or None
        if ctx.aborted:
            return TurnOutcome(
                "failed", error="The run was stopped because it no longer owns its turn.", error_code="lost",
                model=model, usage=state["usage"], partial_text=partial,
            )
        if state["error"]:
            return TurnOutcome(
                "failed", error=state["error"], error_code=state["code"], model=model,
                usage=state["usage"], partial_text=partial,
            )
        text = state["text"]
        if text.strip():
            await sink.emit("assistant.message", {"text": text})
        if state["finish"] == "length":
            return TurnOutcome(
                "failed", error="The answer was cut off at the model's length limit.", error_code="length",
                model=model, usage=state["usage"],
            )
        return TurnOutcome("succeeded", result=text, model=model, usage=state["usage"])


def _error_text(status: int, body: str, secret: str | None) -> str:
    message = body
    try:
        parsed = json.loads(body)
        err = parsed.get("error") if isinstance(parsed, dict) else None
        if isinstance(err, dict) and isinstance(err.get("message"), str):
            message = err["message"]
        elif isinstance(err, str):
            message = err
    except ValueError:
        pass
    message = redact(" ".join(message.split()), secret)[:MAX_ERROR_CHARS]
    return f"The endpoint answered {status}: {message}" if message else f"The endpoint answered {status}."


class OpenRouterAdapter(OpenAIChatAdapter):
    preset = True
    config_fields = [
        {"name": "api_key", "label": "OpenRouter API key", "kind": "secret", "required": True},
        {"name": "model", "label": "Default model", "placeholder": "provider/model"},
    ]
    setup = {
        "credential": "api_key", "docs_url": "https://openrouter.ai/keys",
        "notes": ["Create an OpenRouter key and save it here. Chat only.",
                  "Requests go to OpenRouter and its model providers. Check their data policies before sending private content."],
    }
    """OpenRouter (https://openrouter.ai) as a preset of the OpenAI-compatible
    engine: its own saved configuration (`engine:openrouter`), so it can sit
    beside a local endpoint. The address defaults to OpenRouter's, a key is
    required, and models are OpenRouter ids such as `openai/gpt-4o-mini` or
    `meta-llama/llama-3.3-70b-instruct:free`. Requests to openrouter.ai
    itself also carry OpenRouter's optional app-attribution headers, which tell
    OpenRouter this account's traffic comes from Open Duet; another address (a
    proxy) never gets them."""

    key = "openrouter"
    label = "OpenRouter"
    max_models = 600
    not_configured = "Add your OpenRouter API key in Settings → Engines."

    def validate_config(self, payload: dict, current: dict | None) -> dict:
        base = payload.get("base_url")
        if base and base.strip().rstrip("/") != OPENROUTER_BASE_URL:
            raise InvalidConfig("OpenRouter uses its fixed address. Use the OpenAI-compatible engine for a proxy.")
        payload = {**payload, "base_url": OPENROUTER_BASE_URL}
        config = super().validate_config(payload, current)
        if not config.get("api_key"):
            raise InvalidConfig("Give your OpenRouter API key (openrouter.ai → Keys).")
        return config

    def _headers(self, config: dict) -> dict:
        headers = super()._headers(config)
        if urlsplit(config.get("base_url") or "").hostname == OPENROUTER_HOST:
            headers.update(OPENROUTER_ATTRIBUTION)
        return headers

    async def status(self) -> ProviderStatus:
        probe = await self.probe()
        return ProviderStatus(ready=probe.ready, error=probe.reason, installed=probe.installed, signed_in=probe.signed_in)

    async def probe(self) -> EngineProbe:
        return await self._probe_config(self.config or {})

    async def _probe_config(self, config: dict) -> EngineProbe:
        if not config.get("api_key"):
            return EngineProbe(installed=False, ready=False, reason=self.not_configured)
        if config.get("base_url", OPENROUTER_BASE_URL) != OPENROUTER_BASE_URL:
            return EngineProbe(installed=True, ready=False, reason="Use the OpenAI-compatible engine for a proxy, or save your OpenRouter settings again.")
        try:
            async with self._client(httpx.Timeout(PROBE_TIMEOUT_SECONDS)) as client:
                response = await client.get(f"{OPENROUTER_BASE_URL}/key", headers=self._headers(config))
                if response.status_code in (401, 403):
                    return EngineProbe(installed=True, ready=False, signed_in=False, reason="OpenRouter refused the key. Save a valid key in Settings → Engines.")
                if response.status_code != 200:
                    return EngineProbe(installed=True, ready=False, reason=f"OpenRouter key check answered {response.status_code}. Try again later.")
                try:
                    key_data = response.json().get("data")
                except (ValueError, AttributeError):
                    key_data = None
                if not isinstance(key_data, dict):
                    return EngineProbe(installed=True, ready=False, reason="OpenRouter returned an unreadable key check. Try again later.")
                # A failed catalog must not turn a valid key into a signed-out
                # account. A saved or explicitly chosen model still works.
                try:
                    catalog = await client.get(f"{OPENROUTER_BASE_URL}/models", headers=self._headers(config))
                    data = catalog.json().get("data") if catalog.status_code == 200 else []
                except (httpx.HTTPError, ValueError, AttributeError):
                    data = []
        except httpx.HTTPError as exc:
            return EngineProbe(installed=True, ready=False, reason=f"OpenRouter did not answer ({exc.__class__.__name__}).")
        entries = []
        for item in data if isinstance(data, list) else []:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str):
                continue
            pricing = item.get("pricing")
            free = item["id"].endswith(":free") or (
                isinstance(pricing, dict) and str(pricing.get("prompt")) == "0" and str(pricing.get("completion")) == "0"
            )
            tools = "tools" in (item.get("supported_parameters") or [])
            entries.append((item["id"], free, tools))
        entries.sort(key=lambda item: (not item[1], not item[2], item[0]))
        entries = entries[:self.max_models]
        default = config.get("model")
        if not default and key_data.get("is_free_tier") is True:
            default = next((model for model, free, _ in entries if free), None)
        models = []
        for model, free, _ in entries:
            is_reasoning = any(p in model.lower() for p in ("o1", "o3-mini", "o3", "o4", "r1"))
            efforts = ("low", "medium", "high") if is_reasoning else ()
            models.append(
                ModelOption(
                    model,
                    model + (" (free)" if free else ""),
                    model == default,
                    default_reasoning_effort="medium" if is_reasoning else None,
                    supported_reasoning_efforts=efforts,
                    reasoning_effort_configurable=bool(efforts),
                )
            )
        if default and default not in {m.id for m in models}:
            is_def_reasoning = any(p in default.lower() for p in ("o1", "o3-mini", "o3", "o4", "r1"))
            def_efforts = ("low", "medium", "high") if is_def_reasoning else ()
            models.insert(
                0,
                ModelOption(
                    default,
                    default,
                    True,
                    default_reasoning_effort="medium" if is_def_reasoning else None,
                    supported_reasoning_efforts=def_efforts,
                    reasoning_effort_configurable=bool(def_efforts),
                ),
            )
        return EngineProbe(installed=True, ready=True, signed_in=True, models=models or None)

    async def run_turn(self, ctx: TurnContext, sink, gate) -> TurnOutcome:
        config = ctx.engine_config or self.config or {}
        if not config.get("api_key") or config.get("base_url", OPENROUTER_BASE_URL) != OPENROUTER_BASE_URL:
            return TurnOutcome("failed", error="Save your OpenRouter key in Settings → Engines. For a proxy use the OpenAI-compatible engine.", error_code="engine_not_configured")
        if not ctx.model and not config.get("model"):
            probe = await self._probe_config(config)
            ctx.model = next((model.id for model in probe.models or [] if model.default), None)
        return await super().run_turn(ctx, sink, gate)
