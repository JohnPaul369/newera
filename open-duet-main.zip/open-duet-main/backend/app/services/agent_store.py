"""Persistence for named agents (F06).

Like `thread_store`, every public function is one transaction that takes the
write lock first and commits before it returns. This module knows nothing about
providers or processes: the router checks the provider name and the runtime
applies an agent's settings to a turn.
"""

from datetime import UTC, datetime

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import Agent, Thread
from app.db.models.agent import APPROVAL_MODES
from app.db.transactions import begin_write

# The longest name the API and an agent file accept.
NAME_MAX_CHARS = 80

# Fields `update_agent` may change. `archived` is handled separately.
_EDITABLE = (
    "name",
    "title",
    "description",
    "instructions",
    "provider",
    "model",
    "effort",
    "workspace_path",
    "approval_mode",
    "pinned",
    "memory_enabled",
    "recall_enabled",
    "memory_upkeep",
    "compaction_summary",
    "use_helper",
    "fallback_provider",
    "fallback_model",
    "connector_scopes",
    "connector_account_scopes",
)


class AgentNotFound(Exception):
    pass


class AgentNameTaken(Exception):
    """Another live agent of this owner already has the name."""


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _check_mode(mode: str) -> None:
    if mode not in APPROVAL_MODES:
        raise ValueError(f"approval_mode must be one of {', '.join(APPROVAL_MODES)}")


async def get_agent(db: AsyncSession, agent_id: int) -> Agent | None:
    return await db.get(Agent, agent_id)


async def list_agents(
    db: AsyncSession, owner_id: str, *, include_archived: bool = False
) -> list[Agent]:
    query = select(Agent).where(Agent.owner_id == owner_id)
    if not include_archived:
        query = query.where(Agent.archived_at.is_(None))
    # Pinned first, then by name, so a list in a picker is stable.
    query = query.order_by(Agent.pinned.desc(), Agent.name, Agent.id)
    return list((await db.execute(query)).scalars())


async def create_agent(
    db: AsyncSession,
    *,
    owner_id: str,
    name: str,
    title: str | None = None,
    description: str | None = None,
    instructions: str = "",
    provider: str = "claude",
    model: str | None = None,
    effort: str | None = None,
    workspace_path: str | None = None,
    approval_mode: str = "ask",
    pinned: bool = False,
    memory_enabled: bool = True,
    recall_enabled: bool = True,
    memory_upkeep: bool = True,
    compaction_summary: bool = True,
    use_helper: bool = True,
    make_lead: bool = False,
    fallback_provider: str | None = None,
    fallback_model: str | None = None,
) -> Agent:
    """Raises ValueError (blank name, unknown approval mode) or AgentNameTaken."""
    name = name.strip()
    if not name:
        raise ValueError("name is required")
    _check_mode(approval_mode)
    await begin_write(db)
    now = _utcnow()
    agent = Agent(
        owner_id=owner_id,
        name=name,
        title=title,
        description=description,
        instructions=instructions,
        provider=provider,
        model=model,
        effort=effort,
        workspace_path=workspace_path,
        approval_mode=approval_mode,
        pinned=pinned,
        memory_enabled=memory_enabled,
        recall_enabled=recall_enabled,
        memory_upkeep=memory_upkeep,
        compaction_summary=compaction_summary,
        use_helper=use_helper,
        fallback_provider=fallback_provider,
        fallback_model=fallback_model,
        created_at=now,
        updated_at=now,
    )
    db.add(agent)
    try:
        await db.flush()
        if make_lead:
            from app.team.service import set_lead
            await set_lead(db, owner_id, agent.id, commit=False)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise AgentNameTaken(name) from None
    if make_lead:
        await db.refresh(agent)
    return agent


async def update_agent(
    db: AsyncSession, agent_id: int, *, archived: bool | None = None, make_lead: bool | None = None, **changes
) -> Agent:
    """Change the given fields. Raises AgentNotFound, ValueError, or
    AgentNameTaken (also when un-archiving into a name now in use)."""
    unknown = set(changes) - set(_EDITABLE)
    if unknown:
        raise ValueError(f"cannot change: {', '.join(sorted(unknown))}")
    if "approval_mode" in changes:
        _check_mode(changes["approval_mode"])
    if "name" in changes:
        changes["name"] = changes["name"].strip()
        if not changes["name"]:
            raise ValueError("name is required")
    await begin_write(db)
    agent = await db.get(Agent, agent_id, with_for_update=True)
    if agent is None:
        await db.rollback()
        raise AgentNotFound(agent_id)
    for field, value in changes.items():
        setattr(agent, field, value)
    if "instructions" in changes:
        # The person wrote or looked at these instructions.
        agent.instructions_reviewed_at = _utcnow()
    if archived is not None:
        agent.archived_at = _utcnow() if archived else None
        if archived:
            await _leave_team(db, agent)
            await _pause_agent_routines(db, agent, "archived")
    if make_lead is True:
        if agent.archived_at is not None:
            raise ValueError('Restore this agent before making it lead.')
        from app.team.service import set_lead
        await set_lead(db, agent.owner_id, agent.id, commit=False)
    elif make_lead is False:
        from app.team.service import team_for, audit
        team = await team_for(db, agent.owner_id, lock=True)
        if team is not None and team.lead_agent_id == agent.id:
            team.lead_agent_id = None
            team.updated_at = _utcnow()
            audit(db, team, 'lead_removed', agent_id=agent.id)
    agent.updated_at = _utcnow()
    name = agent.name  # read now: after a rollback the row is expired
    try:
        await db.flush()
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise AgentNameTaken(name) from None
    await db.refresh(agent)
    return agent


async def free_name(db: AsyncSession, owner_id: str, base: str, tag: str = "") -> str:
    """`base` + `tag` when no live agent of the owner has it, else "<base><tag> 2",
    "<base><tag> 3"... `base` is shortened so the name stays within NAME_MAX_CHARS.
    A concurrent writer can still take it; that surfaces as AgentNameTaken."""
    live = set(
        (
            await db.execute(
                select(Agent.name).where(Agent.owner_id == owner_id, Agent.archived_at.is_(None))
            )
        ).scalars()
    )

    def fitted(suffix: str) -> str:
        return base[: NAME_MAX_CHARS - len(suffix)].rstrip() + suffix

    name, number = fitted(tag), 1
    while name in live:
        number += 1
        name = fitted(f"{tag} {number}")
    return name


async def duplicate_agent(db: AsyncSession, agent_id: int, *, safe: bool = False) -> Agent:
    """A copy with the same settings, named "<name> copy" (then "copy 2", ...).
    The copy is live and unpinned, and starts with no notes of its own.
    With `safe`, the copy is never looser than the source: it gets its own folder
    instead of the source's `workspace_path`, and "accept_edits" becomes "ask".
    Raises AgentNotFound."""
    source = await db.get(Agent, agent_id)
    if source is None:
        raise AgentNotFound(agent_id)
    name = await free_name(db, source.owner_id, source.name, " copy")
    return await create_agent(
        db,
        owner_id=source.owner_id,
        name=name,
        title=source.title,
        description=source.description,
        instructions=source.instructions,
        provider=source.provider,
        model=source.model,
        effort=source.effort,
        workspace_path=None if safe else source.workspace_path,
        approval_mode="ask" if safe and source.approval_mode == "accept_edits" else source.approval_mode,
        memory_enabled=source.memory_enabled,
        recall_enabled=source.recall_enabled,
        memory_upkeep=source.memory_upkeep,
        compaction_summary=source.compaction_summary,
        use_helper=source.use_helper,
        fallback_provider=source.fallback_provider,
        fallback_model=source.fallback_model,
    )


async def _pause_agent_routines(db: AsyncSession, agent: Agent, reason_verb: str) -> None:
    from app.db.models.routine import Routine, RoutineRun
    now = _utcnow()
    routine_ids = list((await db.execute(select(Routine.id).where(Routine.agent_id == agent.id))).scalars().all())
    if routine_ids:
        if reason_verb == "deleted":
            err = "Its agent no longer exists."
            reason = "Its agent no longer exists. Choose another agent, then resume."
        else:
            err = "Its agent is archived."
            reason = "Its agent is archived. Unarchive it or choose another agent, then resume."
        await db.execute(
            update(RoutineRun)
            .where(RoutineRun.routine_id.in_(routine_ids), RoutineRun.state == "queued")
            .values(
                state="failed",
                finished_at=now,
                error=err,
            )
        )
        await db.execute(
            update(Routine)
            .where(Routine.id.in_(routine_ids))
            .values(
                paused=True,
                paused_reason=reason,
                next_run_at=None,
                updated_at=now,
            )
        )


async def _leave_team(db: AsyncSession, agent: Agent) -> None:
    """An agent that goes away stops leading and belonging to its team, so the
    team never points at a missing lead."""
    if agent.team_id is None:
        return
    from app.db.models import Team
    team = await db.get(Team, agent.team_id, with_for_update=True)
    if team is not None and team.lead_agent_id == agent.id:
        team.lead_agent_id = None
        team.updated_at = _utcnow()
    agent.team_id = None


async def delete_agent(db: AsyncSession, agent_id: int) -> None:
    """Remove the agent. Its threads keep their whole conversation and simply
    stop being linked: later turns use the thread's own provider and model.
    Raises AgentNotFound."""
    await begin_write(db)
    agent = await db.get(Agent, agent_id, with_for_update=True)
    if agent is None:
        await db.rollback()
        raise AgentNotFound(agent_id)
    await _leave_team(db, agent)
    await _pause_agent_routines(db, agent, "deleted")
    await db.execute(
        update(Thread)
        .where(Thread.agent_id == agent_id)
        .values(agent_id=None, updated_at=Thread.updated_at)
        .execution_options(synchronize_session=False)
    )
    await db.delete(agent)
    await db.commit()
