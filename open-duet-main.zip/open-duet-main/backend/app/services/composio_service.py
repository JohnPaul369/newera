"""Composio connected apps: the saved key and what Settings does with it.

One encrypted row in the credential table (`user_credential`, provider
`integration:composio`, like `engine:<id>`; no migration):

    {"api_key": "ak_...", "user_id": "opendots_<hex>", "session_id": "..." | null}

`user_id` is this installation's one Composio user. Connections belong to that
user, not to a session, so a lost session is replaced without losing them.
The key is never returned, logged or audited; `status()` says only whether
one is saved.
"""

import asyncio
import json
import re
import uuid

from sqlalchemy import delete
from sqlalchemy.ext.asyncio import AsyncSession

from app import composio_catalog, composio_generic, composio_tools
from app.db.models.user_credential import UserCredential
from app.db.transactions import begin_write
from app.services import user_credential_service
from app.services.composio_client import Account, ComposioClient, ComposioError, Link

PROVIDER = "integration:composio"
_NOT_A_FILE = "-"

# The apps that have curated tools (app/composio_tools.py). Any other app Composio lists can be connected too
# (composio_catalog.py) and reached through the generic tools (composio_generic.py).
SUPPORTED_APPS: tuple[tuple[str, str], ...] = tuple((slug, composio_catalog.APP_INFO[slug]["name"]) for slug in composio_tools.apps())
MAX_ACCOUNTS_PER_APP = 5

_KEY = re.compile(r"^ak_[A-Za-z0-9_-]{8,200}$")
_ALIAS = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.-]{0,39}$")

# One key change or session creation at a time.
lock = asyncio.Lock()


class UserError(Exception):
    """A request the owner can fix. `code` is the machine-readable cause."""

    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


def valid_key(key: object) -> bool:
    return isinstance(key, str) and _KEY.match(key) is not None


def valid_alias(alias: object) -> bool:
    return isinstance(alias, str) and _ALIAS.match(alias) is not None


async def load(db: AsyncSession, owner_id: str) -> dict | None:
    """The saved record, or None when there is none or it cannot be read."""
    try:
        found = await user_credential_service.get_decrypted(db, owner_id, PROVIDER)
        record = json.loads(found[0]) if found else None
    except Exception:  # noqa: BLE001  (a row that no longer decrypts reads as no key)
        return None
    if not isinstance(record, dict) or not valid_key(record.get("api_key")) or not isinstance(record.get("user_id"), str):
        return None
    return record


async def _save(db: AsyncSession, owner_id: str, record: dict) -> None:
    await user_credential_service.save_token(
        db, user_id=owner_id, provider=PROVIDER, file_path=_NOT_A_FILE,
        plaintext=json.dumps(record, ensure_ascii=False),
    )


async def configured(db: AsyncSession, owner_id: str) -> bool:
    return await load(db, owner_id) is not None


async def set_key(db: AsyncSession, owner_id: str, key: str, make_client) -> None:
    """Check the key with Composio, then save it. A different key means a
    different project, so the saved session is dropped; the user id stays."""
    if not valid_key(key):
        raise UserError(422, "invalid_composio_key", "A Composio project key starts with ak_ and has no spaces.")
    async with lock:
        previous = await load(db, owner_id)
        user_id = previous["user_id"] if previous else "opendots_" + uuid.uuid4().hex
        try:
            await make_client(key).accounts(user_id)
        except ComposioError as exc:
            raise _user_error(exc, saving=True) from None
        await _save(db, owner_id, {"api_key": key, "user_id": user_id, "session_id": None})
        composio_catalog.invalidate()  # first uses of reviewed reads are in the record and went with it


async def remove_key(db: AsyncSession, owner_id: str) -> None:
    """Forget the key and the session. Connected accounts stay at Composio:
    this does not revoke them."""
    async with lock:
        await begin_write(db)
        await db.execute(
            delete(UserCredential).where(UserCredential.user_id == owner_id, UserCredential.provider == PROVIDER)
        )
        await db.commit()
        composio_catalog.invalidate()


async def known_app(db: AsyncSession, owner_id: str, make_client, slug: str) -> bool:
    """Whether Composio lists an app with this name, asked with the owner's key. False without a key; a failure to ask
    is a UserError, never a guess."""
    if not composio_generic.valid_app(slug) or composio_generic.blocked_app(slug):
        return False
    if slug in composio_tools.apps():
        return True
    record = await load(db, owner_id)
    if record is None:
        return False
    try:
        return await composio_catalog.is_known(make_client(record["api_key"]), slug)
    except ComposioError as exc:
        raise _user_error(exc) from None


async def _needed(db: AsyncSession, owner_id: str) -> dict:
    record = await load(db, owner_id)
    if record is None:
        raise UserError(409, "composio_not_configured", "Add your Composio key in Settings first.")
    return record


def _user_error(exc: ComposioError, *, saving: bool = False) -> UserError:
    if exc.kind == "key_rejected":
        message = (
            "Composio did not accept this key. Check that it is a project key. A scoped key may also be missing "
            "Connected accounts → Read; create a new key after changing scopes."
        ) if saving else (
            "Composio rejected this key. It may be invalid or a scoped permission may be missing. Check Connected "
            "accounts → Read, Session management → Write, and Session tool execution → Write; Connected accounts "
            "→ Write is needed to disconnect accounts. Create and save a new key after changing scopes."
        )
        return UserError(422 if saving else 409, "composio_key_rejected", message)
    if exc.kind == "permission_denied":
        message = (
            "Composio denied this key's permissions. For a scoped project key, enable Connected accounts → Read, "
            "Session management → Write, and Session tool execution → Write. Connected accounts → Write is also "
            "needed to disconnect accounts. Create a new key after changing scopes; permissions are set when the key is created."
        )
        return UserError(403, "composio_permission_denied", message)
    if exc.kind == "rate_limited":
        return UserError(429, "composio_rate_limited", exc.message)
    if exc.kind == "unavailable":
        return UserError(502, "composio_unavailable", exc.message)
    if exc.kind == "not_found":
        return UserError(404, "composio_not_found", exc.message)
    if exc.kind == "bad_response":
        return UserError(502, "composio_bad_response", exc.message)
    return UserError(422, "composio_rejected", exc.message)


async def accounts(db: AsyncSession, owner_id: str, make_client) -> list[Account]:
    record = await _needed(db, owner_id)
    try:
        return await make_client(record["api_key"]).accounts(record["user_id"])
    except ComposioError as exc:
        raise _user_error(exc) from None


async def connect(db: AsyncSession, owner_id: str, make_client, toolkit: str, alias: str | None) -> Link:
    if not composio_generic.valid_app(toolkit) or composio_generic.blocked_app(toolkit):
        raise UserError(422, "unsupported_app", "That app is not available here.")
    if alias is not None and not valid_alias(alias):
        raise UserError(422, "invalid_alias", "Use up to 40 letters, numbers, spaces, dots, dashes or underscores.")
    async with lock:
        record = await _needed(db, owner_id)
        client = make_client(record["api_key"])
        try:
            # An app is connectable only when Composio itself lists it (curated apps always are).
            if toolkit not in composio_tools.apps() and not await composio_catalog.is_known(client, toolkit):
                raise UserError(422, "unsupported_app", "Composio has no app with that name.")
            existing = [a for a in await client.accounts(record["user_id"], toolkit) if a.status != "FAILED"]
            if len(existing) >= MAX_ACCOUNTS_PER_APP:
                raise UserError(409, "too_many_accounts", f"Disconnect an account first; {MAX_ACCOUNTS_PER_APP} is the most per app.")
            alias = alias or "od-" + uuid.uuid4().hex[:6]
            if any((a.alias or "").lower() == alias.lower() for a in existing):
                raise UserError(409, "alias_in_use", "You already have an account with that name for this app.")
            for attempt in range(2):
                session_id = record.get("session_id")
                if not session_id:
                    session_id = await client.create_session(record["user_id"])
                    record = {**record, "session_id": session_id}
                    await _save(db, owner_id, record)
                try:
                    return await client.link(session_id, toolkit, alias)
                except ComposioError as exc:
                    # A session Composio no longer knows is replaced once; the user keeps their accounts.
                    if exc.kind != "not_found" or attempt:
                        raise
                    record = {**record, "session_id": None}
            raise ComposioError("bad_response", "Composio did not give a connect link.")
        except ComposioError as exc:
            raise _user_error(exc) from None


def _agent_error(exc: ComposioError) -> dict:
    """What an agent is told when Composio could not be used. No detail from the
    response is passed on."""
    said = {
        "key_rejected": "Composio rejected the person's key. It may be invalid or a scoped permission may be missing. The owner should check Connected accounts read, Session management write, and Session tool execution write, then replace the key in Settings.",
        "permission_denied": "Composio denied the saved key's permissions. The person needs a project key with Session management and Session tool execution write access; scoped keys also need Connected accounts read access.",
        "rate_limited": "Composio is rate limiting requests. Try again later.",
        "unavailable": "Composio did not answer. Nothing was changed; the read may not have happened.",
        "not_found": "That app, account or tool was not found at Composio.",
    }
    return {"error": said.get(exc.kind, "Composio could not run this."), "code": "composio_" + exc.kind}


def _choose(active: list[Account], alias: str | None, app: str) -> tuple[Account | None, dict | None]:
    if not active:
        return None, {"error": f"No {app} account is connected. The person can connect one in Settings.", "code": "not_connected"}
    names = sorted(a.alias or a.id for a in active)
    if alias is not None:
        match = [a for a in active if (a.alias or "").lower() == alias.lower()]
        if len(match) != 1:
            return None, {"error": "No connected account has that name. Connected: " + ", ".join(names), "code": "unknown_account"}
        return match[0], None
    if len(active) > 1:
        return None, {"error": "More than one account is connected; say which with the account argument: " + ", ".join(names),
                      "code": "account_required"}
    return active[0], None


async def connected_names(db: AsyncSession, owner_id: str, make_client, allowed_apps,
                          allowed_account_ids: dict[str, list[str]] | None = None) -> dict:
    """The names of active accounts that this agent selected, grouped by app."""
    record = await load(db, owner_id)
    if record is None:
        return {"error": "Connected apps are not set up. The person can add their Composio key in Settings.", "code": "not_configured"}
    try:
        found = await make_client(record["api_key"]).accounts(record["user_id"])
    except ComposioError as exc:
        return _agent_error(exc)
    return {"apps": {app: sorted(a.alias or a.id for a in found if a.toolkit == app and a.status == "ACTIVE"
                                  and (allowed_account_ids is None or a.id in allowed_account_ids.get(app, [])))
                     for app in sorted(allowed_apps)}}


async def _session(db: AsyncSession, owner_id: str, client: ComposioClient, record: dict, *, replace: str | None = None) -> tuple[str, dict]:
    """The saved session, or a new one. `replace` names a session that just failed:
    it is replaced only if nobody else already did."""
    async with lock:
        latest = await load(db, owner_id) or record
        session_id = latest.get("session_id")
        if session_id and session_id != replace:
            return session_id, latest
        session_id = await client.create_session(latest["user_id"])
        latest = {**latest, "session_id": session_id}
        await _save(db, owner_id, latest)
        return session_id, latest


OUTCOME_UNKNOWN = {
    "error": "The request was sent but no answer came back, so the change may or may not have been made. "
             "Do not repeat it; ask the person to check.",
    "code": "outcome_unknown",
}
SESSION_EXPIRED = {
    "error": "Composio's session had expired and nothing was changed. Ask the person before trying again.",
    "code": "session_expired",
}
DONE_UNREADABLE = {
    "result": "done", "code": "done_unreadable",
    "note": "The change was made, but the app's answer could not be read. Do not repeat it; ask the person to check.",
}


async def run_tool(db: AsyncSession, owner_id: str, make_client, tool, arguments: dict, alias: str | None, *,
                   account_id: str | None = None, allowed_account_ids: list[str] | None = None,
                   before_execute=None) -> dict:
    """Run one allowed tool as one connected account and return what the agent may see.
    Never raises for a Composio problem: the agent gets a short error instead.

    A read may be retried once on a forgotten session. A change never is: it is sent
    once, and a failure that leaves it unknown is reported as unknown, so the agent is
    told not to repeat it. A change that went through is never reported as a failure."""
    from app import composio_tools

    write = tool.kind == "write"
    record = await load(db, owner_id)
    if record is None:
        return {"error": "Connected apps are not set up. The person can add their Composio key in Settings.", "code": "not_configured"}
    client = make_client(record["api_key"])
    try:
        active = [a for a in await client.accounts(record["user_id"], tool.app) if a.status == "ACTIVE"]
        if allowed_account_ids is not None:
            permitted = set(allowed_account_ids)
            if account_id is not None and account_id not in permitted:
                return {"error": "This agent is not allowed to use that connected account.", "code": "not_allowed"}
            active = [a for a in active if a.id in permitted]
            if not active:
                return {"error": "The selected connected account is no longer connected.", "code": "not_connected"}
        if account_id is not None:
            matches = [a for a in active if a.id == account_id and a.toolkit == tool.app]
            account = matches[0] if len(matches) == 1 else None
            problem = None if account else {"error": "The granted account is no longer connected.", "code": "not_connected"}
        else:
            account, problem = _choose(active, alias, tool.app)
        if problem:
            return problem
        if before_execute is not None:
            refusal = await before_execute(account.id)
            if refusal is not None:
                return refusal
        session_id, record = await _session(db, owner_id, client, record)
    except ComposioError as exc:  # nothing was sent for the tool yet
        return _agent_error(exc)
    try:
        done = await client.execute(session_id, tool.slug, arguments, account.id)
    except ComposioError as exc:
        if write and exc.kind in ("unavailable", "bad_response"):
            return dict(OUTCOME_UNKNOWN)
        if exc.kind != "not_found":
            return _agent_error(exc)
        # Composio forgot the session (the connection belongs to the user, so it is replaced).
        try:
            session_id, record = await _session(db, owner_id, client, record, replace=session_id)
            if write:
                return dict(SESSION_EXPIRED)
            done = await client.execute(session_id, tool.slug, arguments, account.id)
        except ComposioError as again:
            return _agent_error(again)
    if done.result_type == "completed":
        try:
            return composio_tools.project(tool, done.data)
        except composio_tools.BadArguments as exc:
            return dict(DONE_UNREADABLE) if write else {"error": str(exc), "code": "unreadable_answer"}
    if done.result_type == "failed":
        return {"error": "The app refused or could not do that" + (f": {done.error}" if done.error else "."), "code": "app_error"}
    return {"error": "Composio did not run this call.", "code": "not_run"}


async def disconnect(db: AsyncSession, owner_id: str, make_client, account_id: str) -> None:
    record = await _needed(db, owner_id)
    client = make_client(record["api_key"])
    try:
        mine = {a.id for a in await client.accounts(record["user_id"])}
        if account_id not in mine:
            raise UserError(404, "account_not_found", "That account is not connected here.")
        await client.delete_account(account_id)
        from app.services import composio_actions
        await composio_actions.forget(db, owner_id, account_id=account_id)
    except ComposioError as exc:
        error = _user_error(exc)
        if error.code in {"composio_unavailable", "composio_rate_limited"}:
            error.message = "The account was not removed from Composio. Try again; it may still be connected there."
        raise error from None
