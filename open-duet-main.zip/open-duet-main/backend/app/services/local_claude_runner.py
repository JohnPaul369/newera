"""Runs the user's own `claude` CLI on this machine.

By default a run is chat-only: all built-in tools, MCP servers and skills are
turned off. If a flag is missing the CLI refuses to start; there is no fallback
to an unrestricted run.

With tools on (`LOCAL_TOOLS_ENABLED`, a `RunControl` passed in) the CLI gets a
fixed set of tools in permission mode `default` and asks this app, over its
stdin/stdout, before each call it would prompt a person about. No run ever
skips permissions or pre-approves anything.
"""

import base64
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from fastapi.concurrency import run_in_threadpool

from app.core import app_settings, engine_processes
from app.core.engine_env import engine_environment
from app.desktop import profile
from app.services.approval_modes import cli_permission_mode
from app.core import host_exec

# Verified against Claude Code 2.1.232: init reported tools=[], mcp_servers=[],
# skills=[], and a prompt asking to run a shell command wrote nothing.
LOCKDOWN_ARGS = [
    "--tools",
    "",
    "--strict-mcp-config",
    "--disable-slash-commands",
    "--permission-mode",
    "dontAsk",
]

# With tools on, the CLI asks this app (over stdin/stdout) before every tool
# call it would otherwise prompt for in a terminal, and waits for the answer.
# Only these tools exist: no web access, sub-agents, notebooks or MCP.
TOOL_NAMES = "Read,Write,Edit,Glob,Grep,Bash"
TOOLS_ARGS = [
    "--input-format",
    "stream-json",
    "--permission-prompt-tool",
    "stdio",
    "--permission-mode",
    "default",
    "--tools",
    TOOL_NAMES,
    "--strict-mcp-config",
    "--disable-slash-commands",
]

# With a computer, the host's own tools are all off (`--tools ""`): the only
# tools are the computer's, from one MCP server bound to the agent's machine,
# and each call is asked about like any other.
COMPUTER_SERVER = "computer"

_NPM_SHIM_SUFFIXES ={".cmd", ".bat", ".ps1"}
_NPM_REAL_BINARY = Path("node_modules") / "@anthropic-ai" / "claude-code" / "bin" / "claude.exe"

_STATUS_TIMEOUT_SECONDS = 20

_NOT_FOUND = (
    "Claude CLI not found. Install Claude Code, or set LOCAL_CLAUDE_CLI_PATH "
    "to the full path of the real claude executable."
)
# The desktop app has no .env to point at (D-012): it names what it does read.
_NOT_FOUND_DESKTOP = (
    "Claude CLI not found. Install Claude Code, or choose its executable in Settings, "
    "then choose Check again."
)

# stream-json repeats the answer (deltas, snapshots, final result) and adds
# bookkeeping events, so the raw stream is allowed to be larger than the text
# it carries. The text itself is capped separately, at LOCAL_MAX_OUTPUT_BYTES.
RAW_STREAM_SIZE_FACTOR = 8
# Binary results do not count as answer text, but the wire still has finite
# limits so an unfinished or repeated image cannot exhaust the backend.
MAX_STREAM_LINE_BYTES = 16 * 1024 * 1024
MAX_RAW_STREAM_BYTES = 256 * 1024 * 1024


def _stream_text_bytes(line: bytes) -> int:
    """Charge protocol overhead and text, excluding inline image payloads."""
    if b'"image"' not in line or b'"base64"' not in line:
        return len(line)
    try:
        message = json.loads(line)
    except (ValueError, RecursionError):
        return len(line)
    if not isinstance(message, dict) or message.get("type") not in ("user", "assistant"):
        return len(line)
    removed = 0

    def visit(value):
        nonlocal removed
        if isinstance(value, dict):
            source = value.get("source")
            if value.get("type") == "image" and isinstance(source, dict) and source.get("type") == "base64":
                data = source.get("data")
                if isinstance(data, str) and data.isascii():
                    # Keep all metadata and structure in the text budget.
                    # Base64 has no escapes in ordinary stream-json output.
                    removed += len(data)
                    return
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    try:
        visit(message)
    except RecursionError:
        return len(line)
    return max(0, len(line) - removed)

# Return True to stop the run (the process tree is killed and the run is
# reported as having produced too much output).
LineHandler = Callable[[bytes], bool | None]


class ClaudeCliUnavailable(Exception):
    pass


class RunControl:
    """Lets the caller talk to a running process: write lines to its stdin,
    close stdin, and pause the run's time limit while a human decides.

    Passing one to `run_blocking` keeps stdin open after the first message
    (the CLI reads approval answers from it) instead of closing it.
    All methods are safe to call from any thread and never raise.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._proc: subprocess.Popen | None = None
        self._stdin_closed = False
        self._timeout_seconds = 0.0
        self._on_timeout: Callable[[], None] | None = None
        self._timer: threading.Timer | None = None
        self._deadline = 0.0
        self._pauses = 0
        self._remaining = 0.0
        self._finished = False
        self._killed = False

    def _attach(self, proc: subprocess.Popen, timeout_seconds: float, on_timeout) -> None:
        with self._lock:
            self._proc = proc
            if timeout_seconds > 0:
                self._timeout_seconds = timeout_seconds
                self._on_timeout = on_timeout
                self._start_timer(timeout_seconds)
            killed = self._killed
        if killed:  # kill() was called before the process existed
            _kill_tree(proc)

    @property
    def killed(self) -> bool:
        return self._killed

    def kill(self) -> None:
        """Kill the process and everything it started. Safe to call from any
        thread, at any time (before the process starts, while it runs, after it
        ended). Used when the run no longer owns its turn."""
        with self._lock:
            self._killed = True
            proc = self._proc
        if proc is not None:
            _kill_tree(proc)

    def _start_timer(self, seconds: float) -> None:
        self._deadline = time.monotonic() + seconds
        self._timer = threading.Timer(seconds, self._on_timeout)
        self._timer.daemon = True
        self._timer.start()

    def send(self, line: str) -> bool:
        """Write one line to the process. False if it can no longer be written."""
        with self._lock:
            proc = self._proc
            if proc is None or proc.stdin is None or self._stdin_closed:
                return False
            try:
                proc.stdin.write((line.rstrip("\n") + "\n").encode("utf-8"))
                proc.stdin.flush()
                return True
            except (BrokenPipeError, OSError, ValueError):
                return False

    def close_stdin(self) -> None:
        with self._lock:
            self._close_stdin_locked()

    def _close_stdin_locked(self) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None or self._stdin_closed:
            return
        self._stdin_closed = True
        try:
            proc.stdin.close()
        except (BrokenPipeError, OSError, ValueError):
            pass

    def pause_deadline(self) -> None:
        """Stop the clock (nested calls are counted). Waiting for a person is
        not Claude running too long; the wait has its own limit."""
        with self._lock:
            if self._finished or self._timer is None:
                return
            self._pauses += 1
            if self._pauses == 1 and self._timer is not None:
                self._timer.cancel()
                self._remaining = max(self._deadline - time.monotonic(), 0.0)

    def resume_deadline(self) -> None:
        with self._lock:
            if self._finished or self._timer is None or self._pauses == 0:
                return
            self._pauses -= 1
            if self._pauses == 0:
                self._start_timer(self._remaining)

    def _finish(self) -> None:
        with self._lock:
            self._finished = True
            if self._timer is not None:
                self._timer.cancel()
            self._close_stdin_locked()


@dataclass
class RunOutput:
    stdout: str
    stderr: str
    exit_code: int | None
    timed_out: bool = False
    output_truncated: bool = False


@dataclass
class CliStatus:
    installed: bool
    version: str | None = None
    signed_in: bool | None = None
    error: str | None = None


def _resolve_shim(path: Path) -> Path | None:
    """On Windows the npm install exposes `claude.cmd`; killing only that
    wrapper can orphan the real process, so find the real executable."""
    candidate = path.parent / _NPM_REAL_BINARY
    return candidate if candidate.is_file() else None


def resolve_claude_executable() -> Path | None:
    try:
        configured = app_settings.get("LOCAL_CLAUDE_CLI_PATH").strip()
    except app_settings.SettingUnavailable as exc:
        raise ClaudeCliUnavailable(str(exc)) from None
    if configured:
        path = Path(configured)
        if not path.is_file():
            return None
        if path.suffix.lower() in _NPM_SHIM_SUFFIXES:
            return _resolve_shim(path)
        return path

    found = shutil.which("claude.exe") if sys.platform == "win32" else None
    found = found or shutil.which("claude")
    if not found:
        return None
    path = Path(found)
    if path.suffix.lower() in _NPM_SHIM_SUFFIXES:
        return _resolve_shim(path)
    return path


def workspace_dir() -> Path:
    from app.services.workspaces import canonical_workspace
    workspace = canonical_workspace(app_settings.get("LOCAL_WORKSPACE_ROOT"))
    workspace.mkdir(parents=True, exist_ok=True)
    return workspace


def _child_env(*, extra_names=(), extra_env=None) -> dict[str, str]:
    env = engine_environment(extra_names=extra_names)
    if extra_env:
        # Values supplied by an adapter are scoped to this process. The
        # never-list still wins, including for explicit overrides.
        env.update(engine_environment(extra_env, extra_names=extra_env))
    # The CLI's own memory feature can save notes under ~/.claude/projects/,
    # outside the workspace and without asking. Not for runs this app starts;
    # the user's own use of the CLI is unaffected (only this process sees it).
    env["CLAUDE_CODE_DISABLE_AUTO_MEMORY"] = "1"
    # Names this backend, so the next start can end what a hard kill left
    # running (app/core/engine_processes.py).
    return engine_processes.mark(env)


def child_env(*, extra_names=(), extra_env=None) -> dict[str, str]:
    """The environment for any engine process this app starts: the names
    an engine needs (app/core/engine_env.py), not this process's whole
    environment."""
    return _child_env(extra_names=extra_names, extra_env=extra_env)


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                capture_output=True,
                timeout=15,
            )
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except (ProcessLookupError, PermissionError, subprocess.TimeoutExpired):
        pass
    try:
        proc.kill()
    except OSError:
        pass


def run_blocking(
    args: list[str],
    *,
    stdin_text: str | None,
    cwd: Path,
    timeout_seconds: float,
    max_output_bytes: int,
    on_stdout_line: LineHandler | None = None,
    control: RunControl | None = None,
    keep_stdin_open: bool | None = None,
    sandbox: bool = False,
    sandbox_writable=(),
    sandbox_readonly=(),
) -> RunOutput:
    """Run a process to completion with a time limit and an output cap,
    killing its whole process tree if either is exceeded.

    With `on_stdout_line`, stdout is handed over one line at a time, as it
    arrives (split on raw bytes at b"\n", a trailing b"\r" dropped), and is not
    kept in the returned `RunOutput`.

    With `control`, `stdin_text` is sent as one line and stdin stays open so
    the caller can keep writing; the caller (or the end of the run) closes it,
    and the time limit is owned by `control` so it can be paused. With
    `keep_stdin_open=False` a control only provides the kill switch and the
    pausable time limit: the text is written and stdin closed, as without one."""
    if keep_stdin_open is None:
        keep_stdin_open = control is not None
    popen_kwargs: dict = {}
    if sys.platform == "win32":
        popen_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    else:
        popen_kwargs["start_new_session"] = True

    host_exec.ensure_allowed("an engine process")
    env = _child_env()
    if sandbox:
        from app.core import turn_sandbox
        turn_sandbox.self_check()
        args = turn_sandbox.command(args, cwd=cwd, env=env, writable=sandbox_writable, readonly=sandbox_readonly)
    proc = subprocess.Popen(
        args,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env=env,
        **popen_kwargs,
    )
    engine_processes.record(proc.pid, args[0])

    state = {"timed_out": False, "truncated": False}
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []

    def on_timeout() -> None:
        state["timed_out"] = True
        _kill_tree(proc)

    def drain(stream, chunks: list[bytes], *, fatal_on_overflow: bool) -> None:
        total = 0
        while True:
            chunk = stream.read(65536)
            if not chunk:
                return
            total += len(chunk)
            if total > max_output_bytes:
                if fatal_on_overflow:
                    state["truncated"] = True
                    _kill_tree(proc)
                return
            chunks.append(chunk)

    def drain_lines(stream) -> None:
        total = 0
        raw_total = 0
        pending = b""

        def handle(line: bytes) -> bool:
            try:
                return bool(on_stdout_line(line.removesuffix(b"\r")))
            except Exception:
                return False  # a faulty handler must not end the run

        while True:
            # read1 returns what is available; read(n) would wait for n bytes
            # and defeat streaming.
            chunk = stream.read1(65536)
            if not chunk:
                break
            raw_total += len(chunk)
            if raw_total > MAX_RAW_STREAM_BYTES:
                state["truncated"] = True
                _kill_tree(proc)
                return
            pending += chunk
            *lines, pending = pending.split(b"\n")
            if len(pending) > MAX_STREAM_LINE_BYTES:
                state["truncated"] = True
                _kill_tree(proc)
                return
            for line in lines:
                total += _stream_text_bytes(line) + 1
                if len(line) > MAX_STREAM_LINE_BYTES or total > max_output_bytes or handle(line):
                    state["truncated"] = True
                    _kill_tree(proc)
                    return
        if pending and (total + _stream_text_bytes(pending) > max_output_bytes or handle(pending)):
            state["truncated"] = True
            _kill_tree(proc)

    timer = None if control is not None or timeout_seconds <= 0 else threading.Timer(timeout_seconds, on_timeout)
    stdout_reader = (
        threading.Thread(target=drain_lines, args=(proc.stdout,))
        if on_stdout_line is not None
        else threading.Thread(
            target=drain, args=(proc.stdout, stdout_chunks), kwargs={"fatal_on_overflow": True}
        )
    )
    readers = [
        stdout_reader,
        threading.Thread(target=drain, args=(proc.stderr, stderr_chunks), kwargs={"fatal_on_overflow": False}),
    ]
    if control is not None:
        control._attach(proc, timeout_seconds, on_timeout)
    elif timer is not None:
        timer.start()
    for reader in readers:
        reader.start()
    try:
        if control is not None and keep_stdin_open:
            if stdin_text is not None:
                control.send(stdin_text)
        else:
            try:
                if stdin_text is not None:
                    proc.stdin.write(stdin_text.encode("utf-8"))
                proc.stdin.close()
            except (BrokenPipeError, OSError):
                pass
        proc.wait()
    finally:
        if control is not None:
            control._finish()
        elif timer is not None:
            timer.cancel()
        # A killed child's grandchildren could still hold the pipes open.
        for reader in readers:
            reader.join(timeout=5)
        if proc.poll() is None:
            _kill_tree(proc)
        engine_processes.forget(proc.pid)

    return RunOutput(
        stdout=b"".join(stdout_chunks).decode("utf-8", errors="replace"),
        stderr=b"".join(stderr_chunks).decode("utf-8", errors="replace"),
        exit_code=proc.returncode,
        timed_out=state["timed_out"],
        output_truncated=state["truncated"],
    )


def build_args(
    executable: Path,
    session_id: str,
    *,
    tools: bool = False,
    resume: bool = False,
    approval_mode: str | None = None,
    model: str | None = None,
    system_prompt: str | None = None,
    computer=None,
    mcp_servers: dict | None = None,
    mcp_only: bool = False,
) -> list[str]:
    # The prompt goes in on stdin, never on the command line. `resume` continues
    # the conversation that already holds `session_id`; otherwise the CLI is
    # told to create it under that id.
    common = [
        str(executable),
        "-p",
        "--verbose",
        "--include-partial-messages",
        "--resume" if resume else "--session-id",
        session_id,
    ]
    # An agent's model, and its instructions added to the CLI's own system
    # prompt (never replacing it). Both are argument values, not shell text.
    if model:
        common += ["--model", model]
    if system_prompt:
        common += ["--append-system-prompt", system_prompt]
    if not tools and computer is None and not mcp_servers:
        return [*common, "--output-format", "stream-json", *LOCKDOWN_ARGS]
    # Only the tools path has a permission mode to choose; chat-only runs stay
    # locked down. `None` keeps the CLI's `default` (ask about everything).
    tools_args = list(TOOLS_ARGS)
    tools_args[tools_args.index("--permission-mode") + 1] = cli_permission_mode(approval_mode)
    if computer is not None or mcp_only:
        tools_args[tools_args.index("--tools") + 1] = ""
    servers = dict(mcp_servers or {})
    if computer is not None:
        servers[COMPUTER_SERVER] = computer
    if servers:
        tools_args += ["--mcp-config", mcp_config(servers)]
    return [*common, "--output-format", "stream-json", *tools_args]


def mcp_config(servers: dict) -> str:
    config = {}
    for name, launch in servers.items():
        server = {"type": "stdio", "command": launch.command, "args": list(launch.args)}
        if launch.env:
            server["env"] = dict(launch.env)
        config[name] = server
    return json.dumps({"mcpServers": config}, ensure_ascii=False)


def computer_mcp_config(launch) -> str:
    """The `--mcp-config` value naming the computer's MCP server (and nothing
    else: `--strict-mcp-config` keeps every other server out)."""
    server = {"type": "stdio", "command": launch.command, "args": list(launch.args)}
    if launch.env:
        server["env"] = dict(launch.env)
    return json.dumps({"mcpServers": {COMPUTER_SERVER: server}}, ensure_ascii=False)


def user_message_line(prompt: str, images: list[dict] | None = None) -> str:
    """The prompt as the one stream-json message a run starts with. With
    images, the content is a text block followed by one base64 image block per
    image (the Messages API content-block shape the CLI accepts on stdin)."""
    content: str | list[dict] = prompt
    if images:
        content = [{"type": "text", "text": prompt}] + [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": image["mime"],
                    "data": base64.b64encode(Path(image["path"]).read_bytes()).decode("ascii"),
                },
            }
            for image in images
        ]
    return json.dumps(
        {"type": "user", "message": {"role": "user", "content": content}},
        ensure_ascii=False,
    )


def _status_blocking() -> CliStatus:
    try:
        executable = resolve_claude_executable()
    except ClaudeCliUnavailable as exc:
        return CliStatus(installed=False, error=str(exc))
    if executable is None:
        return CliStatus(installed=False, error=_NOT_FOUND_DESKTOP if profile.active() else _NOT_FOUND)

    # Authentication is account-wide, independent of the default workspace.
    # A broken default must not prevent resuming a thread in its pinned folder.
    cwd = Path.home()

    def call(*extra: str) -> RunOutput:
        return run_blocking(
            [str(executable), *extra],
            stdin_text=None,
            cwd=cwd,
            timeout_seconds=_STATUS_TIMEOUT_SECONDS,
            max_output_bytes=100_000,
        )

    version = call("--version")
    if version.exit_code != 0:
        return CliStatus(installed=False, error="The Claude CLI did not start.")

    status = CliStatus(installed=True, version=version.stdout.strip() or None)
    auth = call("auth", "status", "--json")
    try:
        # Only loggedIn is read: the payload also carries the account's email
        # and organisation, which must not be forwarded or logged.
        status.signed_in = bool(json.loads(auth.stdout).get("loggedIn"))
    except (json.JSONDecodeError, AttributeError):
        status.signed_in = None
        status.error = "Could not determine whether Claude is signed in."
        return status
    if not status.signed_in:
        status.error = "Claude is not signed in. Open engine settings to sign in."
    return status


async def get_status() -> CliStatus:
    return await run_in_threadpool(_status_blocking)


def _run_blocking(
    prompt: str,
    session_id: str,
    on_stdout_line: LineHandler | None,
    control: RunControl | None,
    resume: bool = False,
    tools: bool | None = None,
    workspace: Path | None = None,
    approval_mode: str | None = None,
    model: str | None = None,
    system_prompt: str | None = None,
    computer=None,
    mcp_servers: dict | None = None,
    images: list[dict] | None = None,
    mcp_only: bool = False,
) -> RunOutput:
    if workspace is not None:
        from app.services.workspaces import require_workspace
        require_workspace(workspace)
    executable = resolve_claude_executable()
    if executable is None:
        raise ClaudeCliUnavailable("Claude CLI not found.")
    if tools is None:
        tools = control is not None
    extra = {"resume": True} if resume else {}
    if approval_mode is not None:
        extra["approval_mode"] = approval_mode  # unset: build_args behaves as before
    if model:
        extra["model"] = model
    if system_prompt:
        extra["system_prompt"] = system_prompt
    if computer is not None:
        tools = True
        extra["computer"] = computer  # unset: build_args behaves as before
    if mcp_servers:
        tools = True
        extra["mcp_servers"] = mcp_servers
        if mcp_only:
            extra["mcp_only"] = True
    args = (
        build_args(executable, session_id, tools=True, **extra)
        if tools
        else build_args(executable, session_id, **extra)
    )
    # Images need a stream-json message; a chat-only run otherwise reads plain
    # text, so the input format is switched for that run only.
    if images and not tools:
        args = [*args, "--input-format", "stream-json"]
    from app.core import turn_sandbox
    return run_blocking(
        args,
        sandbox=True,
        sandbox_writable=turn_sandbox.mailbox_mounts((mcp_servers or {}).values()),
        sandbox_readonly=[Path(image["path"]) for image in (images or [])],
        stdin_text=user_message_line(prompt, images) if tools or images else prompt,
        cwd=workspace_dir() if workspace is None else workspace,
        timeout_seconds=app_settings.get("LOCAL_TASK_TIMEOUT_SECONDS"),
        max_output_bytes=app_settings.get("LOCAL_MAX_OUTPUT_BYTES") * RAW_STREAM_SIZE_FACTOR,
        on_stdout_line=on_stdout_line,
        control=control,
        keep_stdin_open=tools if control is not None else None,
    )


async def run_prompt(
    prompt: str,
    session_id: str,
    on_stdout_line: LineHandler | None = None,
    control: RunControl | None = None,
    *,
    resume: bool = False,
    tools: bool | None = None,
    workspace: Path | None = None,
    approval_mode: str | None = None,
    model: str | None = None,
    system_prompt: str | None = None,
    computer=None,
    mcp_servers: dict | None = None,
    images: list[dict] | None = None,
    mcp_only: bool = False,
) -> RunOutput:
    """Chat-only by default. Passing a `RunControl` runs with tools on: the CLI
    then asks over stdin/stdout before each tool call, and the caller answers
    through `control`. `tools=False` with a control gives a chat-only run the
    caller can still kill; `resume=True` continues the session `session_id`
    instead of creating it. `approval_mode` (see approval_modes.py) only
    matters with tools on. `computer` (an MCP launch) runs with tools on, but
    with the computer's tools in place of the host's."""
    return await run_in_threadpool(
        _run_blocking,
        prompt,
        session_id,
        on_stdout_line,
        control,
        resume,
        tools,
        workspace,
        approval_mode,
        model,
        system_prompt,
        computer,
        mcp_servers,
        images,
        mcp_only,
    )
