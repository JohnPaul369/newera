"""Teams and bounded delegation."""
